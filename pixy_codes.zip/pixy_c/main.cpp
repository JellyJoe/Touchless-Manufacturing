/*PrimeDev - 2016*/
#include <stdio.h>
#include <tchar.h>
#include "header.h"  // Library described above
#include <string>
#include <iostream>
using namespace std;

// application reads from the specified serial port and reports the collected data
int main()
{

    printf("Welcome to the serial test app!\n\n");
    //serial port number
    Serial* SP = new Serial("\\\\.\\COM4");    // adjust as needed

    if (SP->IsConnected())
        printf("We're connected");
    //buffer
    char incomingData[256] = "";// don't forget to pre-allocate memory
    string x, y, z;
    char * getValue;
    int dataLength = 255;
    int result = 0;
    int counter = 0;
    printf("\n");

    while (SP->IsConnected())//loop if serial is connected
    {
        result = SP->ReadData(incomingData, dataLength);//read data in serial
        incomingData[result] = '\0';

        if(incomingData != NULL)//buffer is not empty
        {
            getValue = strtok(incomingData, " ");//seperate the buffer's values
            while(getValue != NULL)
            {
                if(counter == 0)//1st seperated value
                {
                    x = getValue;
                    counter++;//increment counter
                    cout << "x:" << x << "\t";
                }
                else if(counter == 1)//2nd seperated value
                {
                    y = getValue;
                    counter++;//increment counter
                    cout << "y:" << y << "\t";
                }
                else if(counter == 2)//3rd seperated value
                {
                    z = getValue;
                    cout << "z:" << z << endl;
                    counter = 0;//reset counter
                }
                getValue  = strtok(NULL, " ");
                Sleep(500);//sleep 0.5 sec
            }

        }
    }


    return 0;
}

